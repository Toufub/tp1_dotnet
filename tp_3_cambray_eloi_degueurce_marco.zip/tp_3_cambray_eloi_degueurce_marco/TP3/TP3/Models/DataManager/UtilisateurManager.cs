﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TP3.Models.EntityFramework;
using TP3.Models.Repository;

namespace TP3.Models.DataManager
{
    public class UtilisateurManager : IDataRepository<Utilisateur>
    {
        readonly SerieDBContext? serieDBContext;
        public UtilisateurManager() { }
        public UtilisateurManager(SerieDBContext context)
        {
            serieDBContext = context;
        }
        public ActionResult<IEnumerable<Utilisateur>> GetAll()
        {
            return serieDBContext.Utilisateurs.ToList();
        }
        public ActionResult<Utilisateur> GetById(int id)
        {
            return serieDBContext.Utilisateurs.FirstOrDefault(u => u.UtilisateurId == id);
        }
        public async Task<ActionResult<Utilisateur>> GetByStringAsync(string mail)
        {
            return await serieDBContext.Utilisateurs.FirstOrDefaultAsync(u => u.Mail.ToUpper() == mail.ToUpper());
        }
        public async Task AddAsync(Utilisateur entity)
        {
            await serieDBContext.Utilisateurs.AddAsync(entity);
            await serieDBContext.SaveChangesAsync();
        }
        public async Task Update(Utilisateur utilisateur, Utilisateur entity)
        {
            serieDBContext.Entry(utilisateur).State = EntityState.Modified;
            utilisateur.UtilisateurId = entity.UtilisateurId;
            utilisateur.Nom = entity.Nom;
            utilisateur.Prenom = entity.Prenom;
            utilisateur.Mail = entity.Mail;
            utilisateur.Rue = entity.Rue;
            utilisateur.CodePostale = entity.CodePostale;
            utilisateur.Ville = entity.Ville;
            utilisateur.Pays = entity.Pays;
            utilisateur.Latitude = entity.Latitude;
            utilisateur.Longitude = entity.Longitude;
            utilisateur.Pwd = entity.Pwd;
            utilisateur.Mobile = entity.Mobile;
            utilisateur.NotesUtilisateur = entity.NotesUtilisateur;
            await serieDBContext.SaveChangesAsync();
        }
        public async Task Delete(Utilisateur utilisateur)
        {
            serieDBContext.Utilisateurs.Remove(utilisateur);
            await serieDBContext.SaveChangesAsync();
        }
    }
}
