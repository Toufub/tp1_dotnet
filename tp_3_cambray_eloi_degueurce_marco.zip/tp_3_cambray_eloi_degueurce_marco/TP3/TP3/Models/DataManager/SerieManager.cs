﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TP3.Models.EntityFramework;
using TP3.Models.Repository;

namespace TP3.Models.DataManager
{
    public class SerieManager : IDataRepository<Serie>
    {
        readonly SerieDBContext? serieDBContext;
        public SerieManager() { }
        public SerieManager(SerieDBContext context)
        {
            serieDBContext = context;
        }
        public ActionResult<IEnumerable<Serie>> GetAll()
        {
            return serieDBContext.Series.ToList();
        }
        public ActionResult<Serie> GetById(int id)
        {
            return serieDBContext.Series.FirstOrDefault(s => s.Id == id);
        }
        public async Task<ActionResult<Serie>> GetByStringAsync(string titre)
        {
            return await serieDBContext.Series.FirstOrDefaultAsync(s => s.Titre == titre);
        }
        public async Task AddAsync(Serie entity)
        {
            await serieDBContext.Series.AddAsync(entity);
            await serieDBContext.SaveChangesAsync();
        }
        public async Task Update(Serie serie, Serie entity)
        {
            serieDBContext.Entry(serie).State = EntityState.Modified;
            serie.Id = entity.Id;
            serie.Titre = entity.Titre;
            serie.Network = entity.Network;
            serie.NbSaisons = entity.NbSaisons;
            serie.NbEpsiodes = entity.NbEpsiodes;
            serie.AnneeCreation = entity.AnneeCreation;
            serie.Resume = entity.Resume;
            serie.NotesSeries = entity.NotesSeries;
            await serieDBContext.SaveChangesAsync();
        }
        public async Task Delete(Serie serie)
        {
            serieDBContext.Series.Remove(serie);
            await serieDBContext.SaveChangesAsync();
        }
    }
}
