﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TP3.Models.EntityFramework;
using TP3.Models.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TP3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeriesController : ControllerBase
    {
        private readonly SerieDBContext _context;
        private readonly IDataRepository<Serie> dataRepository;

        public SeriesController(IDataRepository<Serie> dataRepo)
        {
            dataRepository = dataRepo;
        }

        // GET: api/Series
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Serie>>> GetSeries()
        {
            return dataRepository.GetAll();
        }

        // GET: api/Series/5
        [HttpGet]
        [Route("[action]/{id}")]
        public async Task<ActionResult<Serie>> GetSerieById(int id)
        {
            var serie = dataRepository.GetById(id);
           
            if (serie == null)
            {
                return NotFound();
            }

            return serie;
        }

        // GET: api/Series/how i met your mother
        [HttpGet]
        [Route("[action]/{titre}")]
        public async Task<ActionResult<Serie>> GetSerieByTitre(string titre)
        {
            var serie = await dataRepository.GetByStringAsync(titre);
            if (serie == null)
            {
                return NotFound();
            }
            return serie;
        }

        // PUT: api/Series/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut]
        [Route("/{id}")]
        public async Task<IActionResult> PutSerie(int id, Serie serie)
        {
            if (id != serie.Id)
            {
                return BadRequest();
            }

            var serieToUpdate = dataRepository.GetById(id);
            if (serieToUpdate == null)
            {
                return NotFound();
            }
            dataRepository.Update(serieToUpdate.Value, serie);

            return NoContent();
        }

        [HttpPatch]
        [Route("/{id}")]
        public async Task<ActionResult<Serie>> Patch(int id, [FromBody] JsonPatchDocument<Serie> patchSerie)
        {
            var entity = await _context.Series
                .Where(s => s.Id == id)
                .FirstOrDefaultAsync();

            if (entity == null)
            {
                return NotFound();
            }

            patchSerie.ApplyTo(entity, ModelState); // Must have Microsoft.AspNetCore.Mvc.NewtonsoftJson installed

            return entity;
        }

        // POST: api/Series
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Utilisateur>> PostSerie(Serie serie)
        {
            await dataRepository.AddAsync(serie);

            return CreatedAtAction("GetSerieById", new { id = serie.Id }, serie);
        }


        // DELETE: api/Series/5
        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteSerie(int id)
        {
            var serie = dataRepository.GetById(id);
            if (serie == null)
            {
                return NotFound();
            }

            dataRepository.Delete(serie.Value);

            return NoContent();
        }

    }
}