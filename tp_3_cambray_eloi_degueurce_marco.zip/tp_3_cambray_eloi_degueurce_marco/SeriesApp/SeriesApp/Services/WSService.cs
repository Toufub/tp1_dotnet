﻿using Newtonsoft.Json;
using SeriesApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Windows.Media.Protection.PlayReady;

namespace SeriesApp.Services;
internal class WSService
{
    private HttpClient httpClient = new();

    public WSService()
    {
        httpClient.BaseAddress = new Uri("https://localhost:7049/api/");
        httpClient.DefaultRequestHeaders.Accept.Clear();
        httpClient.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));
    }

    public async Task<ObservableCollection<Utilisateur>> GetUtilisateursAsync()
    {
        try
        {
            HttpResponseMessage response = await httpClient.GetAsync("https://localhost:7049/api/utilisateurs");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<ObservableCollection<Utilisateur>>();
            }
        }
        catch (Exception e) { }
        return new ObservableCollection<Utilisateur>();
    }

    public async Task<Utilisateur> GetUtilisateurByEmailAsync(string email)
    {
        try
        {
            HttpResponseMessage response = await httpClient.GetAsync("https://localhost:7049/api/utilisateurs/GetUtilisateurByEmail/" + email);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<Utilisateur>();
            }
        }
        catch (Exception e) {
            int i = 10;
        }
        return new Utilisateur();
    }

    public async Task<String> AddUserAsync(Utilisateur user)
    {
        try
        {
            var utilisateur = JsonConvert.SerializeObject(user);
            var requestContent = new StringContent(utilisateur, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await httpClient.PostAsJsonAsync("https://localhost:7049/api/utilisateurs/",
                requestContent);
            if (response.IsSuccessStatusCode)
            {
                return "Succès !";
            } else
            {
                return response.Content.ToString() ;
            }
        }
        catch (Exception e)
        {
        }
        return "Erreur serveur.";
    }

    public async Task<String> ModifyUserAsync(Utilisateur user)
    {
        try
        {
            var utilisateur = JsonConvert.SerializeObject(user);
            var requestContent = new StringContent(utilisateur, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await httpClient.PutAsJsonAsync("https://localhost:7049/api/utilisateurs/" + user.UtilisateurId.ToString(),
                requestContent);
            if(response.IsSuccessStatusCode)
            {
                return "Succès !";
            } else
            {
                return response.Content.ToString();
            }
        }
        catch (Exception e)
        {
        }
        return "Erreur serveur.";
    }
}

