﻿namespace SeriesApp.Behaviors;

public enum NavigationViewHeaderMode
{
    Always,
    Never,
    Minimal
}
