﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeriesApp.Models;

public class Serie
{
    public Serie()
    {
        NotesSeries = new HashSet<Notation>();
    }

    public int Id { get; set; }
    public string Titre { get; set; } = null!;
    public string? Resume { get; set; }

    public int? NbSaisons { get; set; }

    public int? NbEpsiodes { get; set; }

    public int? AnneeCreation { get; set; }

    public string? Network { get; set; }
    public virtual ICollection<Notation> NotesSeries { get; set; }
}

