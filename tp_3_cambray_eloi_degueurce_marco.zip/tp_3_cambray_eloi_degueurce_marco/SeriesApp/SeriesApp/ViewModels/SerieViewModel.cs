﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SeriesApp.ViewModels;

public class SerieViewModel : ObservableRecipient
{
    public SerieViewModel()
    {
    }
}
