﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SeriesApp.ViewModels;

public class HomeViewModel : ObservableRecipient
{
    public HomeViewModel()
    {
    }
}
