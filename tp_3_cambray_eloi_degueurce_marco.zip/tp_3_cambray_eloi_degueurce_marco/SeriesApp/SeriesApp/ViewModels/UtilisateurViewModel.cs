﻿using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.UI.Xaml.Controls;
using SeriesApp.Services;
using SeriesApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeriesApp.ViewModels;

public class UtilisateurViewModel : ObservableObject
{

    private WSService service = new WSService();
    public IRelayCommand BtnRechercher
    {
        get;
    }

    public IRelayCommand BtnClearUtilisateurCommand
    {
        get;
    }

    public IRelayCommand BtnModifyUtilisateurCommand
    {
        get;
    }
    public IRelayCommand BtnAddUtilisateurCommand
    {
        get;
    }

    public UtilisateurViewModel()
    {
        utilisateur = new Utilisateur();
        BtnRechercher = new RelayCommand(ActionSearch);
        BtnClearUtilisateurCommand = new RelayCommand(ClearUser);
        BtnModifyUtilisateurCommand = new RelayCommand(ModifyUser);
        BtnAddUtilisateurCommand = new RelayCommand(AddUser);

    }
    private async void ActionSearch()
    {
        try
        {
            Utilisateur = await service.GetUtilisateurByEmailAsync(MailSearch);
        }
        catch
        {
            this.DisplayErrorDialog("Impossible de trouver l'utilisateur.", "Merci de rééssayer plus tard.");
        }
    }

    private void ClearUser()
    {
        Utilisateur = null;
    }
    private async void ModifyUser()
    {
        var val_retour = await service.ModifyUserAsync(Utilisateur);
        this.DisplayErrorDialog("Retour", val_retour);
    }
    private async void AddUser()
    {
        var val_retour = await service.AddUserAsync(Utilisateur);
        this.DisplayErrorDialog("Retour", val_retour);
    }

    private Utilisateur utilisateur;
    public Utilisateur Utilisateur
    {
        get
        {
            return utilisateur;
        }
        set
        {
            utilisateur = value;
            OnPropertyChanged();
        } 
    }

    private string mailSearch;
    public string MailSearch
    {
        get
        {
            return mailSearch;
        }
        set
        {
            mailSearch = value;
            OnPropertyChanged();
        }
    }

    private async void DisplayErrorDialog(String title, String content)
    {
        ContentDialog dialog = new ContentDialog
        {
            Title = title,
            Content = content,
            CloseButtonText = "Ok"
        };
        dialog.XamlRoot = App.MainRoot.XamlRoot;
        await dialog.ShowAsync();
    }
}

