﻿using SeriesApp.ViewModels;
using Microsoft.UI.Xaml.Controls;

namespace SeriesApp.Views;

public sealed partial class UtilisateurPage : Page
{

    public UtilisateurPage()
    {
        UtilisateurViewModel ViewModel = App.GetService<UtilisateurViewModel>();
        DataContext = ViewModel;
        InitializeComponent();
    }
}
